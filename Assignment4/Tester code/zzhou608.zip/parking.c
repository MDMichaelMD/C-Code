/*
 * Parking System Analysis Program
 * This program processes parking data to perform three types of analysis:
 * 1. Identify duplicate parking permits (p)
 * 2. Calculate median parking duration per lot (d)
 * 3. Find maximum occupancy across all lots (o)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Structure to store each parking record
 * Times are stored in minutes since midnight for easier calculations
 */
typedef struct {
    int entry_time;      // Time of entry in minutes since midnight
    int exit_time;       // Time of exit in minutes since midnight
    int lot_index;       // Index of the parking lot
    int permit_num;      // Parking permit number
    int original_order;  // Original position in input file (for maintaining order in output)
} ParkingRecord;

// Function prototypes for sorting and utility functions
void merge_sort_records(ParkingRecord arr[], int left, int right, int key);
void merge_records(ParkingRecord arr[], int left, int mid, int right, int key);
void merge_sort_int(int arr[], int left, int right);
void merge_int(int arr[], int left, int mid, int right);
int time_to_minutes(char *time_str);
double calculate_median(int durations[], int count);

/* Main function: Handles command-line arguments, file I/O, and operation selection */
int main(int argc, char *argv[]) {
    // Verify correct number of command-line arguments
    if (argc != 3) {
        fprintf(stderr, "Usage: ./parking <input_file> <p|d|o>\n");
        return 1;
    }

    char *filename = argv[1];
    char mode = argv[2][0];

    // Open and validate input file
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    // Read number of records from first line
    int num_records;
    if (fscanf(file, "%d", &num_records) != 1) {
        fprintf(stderr, "Error reading the number of records.\n");
        fclose(file);
        return 1;
    }

    // Allocate memory for parking records array
    ParkingRecord *records = malloc(num_records * sizeof(ParkingRecord));
    if (!records) {
        perror("Memory allocation failed");
        fclose(file);
        return 1;
    }

    // Read each parking record from the file
    for (int i = 0; i < num_records; i++) {
        char entry_str[6], exit_str[6];
        if (fscanf(file, "%s %s %d %d", entry_str, exit_str, &records[i].lot_index, &records[i].permit_num) != 4) {
            fprintf(stderr, "Error reading record %d.\n", i + 1);
            free(records);
            fclose(file);
            return 1;
        }
        // Convert time strings to minutes since midnight
        records[i].entry_time = time_to_minutes(entry_str);
        records[i].exit_time = time_to_minutes(exit_str);
        records[i].original_order = i;
    }

    fclose(file);

    // Process based on mode selection
    if (mode == 'p') {
        /* Mode 'p': Find and print duplicate parking permits
        * Algorithm:
        * 1. Create sorted copy of records by permit number
        * 2. Identify permits that appear multiple times
        * 3. Collect duplicate records
        * 4. Sort duplicate records by permit number
        * 5. Print sorted duplicate records
        */

        // Create sorted copy for finding duplicates
        ParkingRecord *sorted_records = malloc(num_records * sizeof(ParkingRecord));
        if (!sorted_records) {
            perror("Memory allocation failed");
            free(records);
            return 1;
        }
        memcpy(sorted_records, records, num_records * sizeof(ParkingRecord));

        // Sort by permit number
        merge_sort_records(sorted_records, 0, num_records - 1, 3);

        // Array to store duplicate permit numbers
        int *duplicate_permits = malloc(num_records * sizeof(int));
        if (!duplicate_permits) {
            perror("Memory allocation failed");
            free(records);
            free(sorted_records);
            return 1;
        }
        int dup_count = 0;

        // Find all permits that appear more than once
        int i = 0;
        while (i < num_records) {
            int current_permit = sorted_records[i].permit_num;
            int count = 1;
            int j = i + 1;
            while (j < num_records && sorted_records[j].permit_num == current_permit) {
                count++;
                j++;
            }
            if (count > 1) {
                duplicate_permits[dup_count++] = current_permit;
            }
            i = j;
        }

        free(sorted_records);

        // Collect duplicate records into an array
        ParkingRecord *duplicate_records = malloc(num_records * sizeof(ParkingRecord));
        if (!duplicate_records) {
            perror("Memory allocation failed");
            free(records);
            free(duplicate_permits);
            return 1;
        }
        int dup_rec_index = 0;

        // Populate the array with duplicate records
        for (int j = 0; j < num_records; j++) {
            int permit_num = records[j].permit_num;
            for (int k = 0; k < dup_count; k++) {
                if (permit_num == duplicate_permits[k]) {
                    duplicate_records[dup_rec_index++] = records[j];
                    break;
                }
            }
        }

        // Sort the duplicate records by permit number
        merge_sort_records(duplicate_records, 0, dup_rec_index - 1, 3); // key = 3 for permit_num

        // Print the sorted duplicate records
        for (int i = 0; i < dup_rec_index; i++) {
            printf("%d %d %d:%02d %d:%02d\n",
                duplicate_records[i].permit_num,
                duplicate_records[i].lot_index,
                duplicate_records[i].entry_time / 60, duplicate_records[i].entry_time % 60,
                duplicate_records[i].exit_time / 60, duplicate_records[i].exit_time % 60);
        }

        free(duplicate_records);
        free(duplicate_permits);

    }
    else if (mode == 'd') {
        /* Mode 'd': Calculate median parking duration for each lot
         * Algorithm:
         * 1. Find total number of lots
         * 2. Group durations by lot
         * 3. Sort durations within each lot
         * 4. Calculate and print median duration for each lot
         */

        // Find highest lot index to determine number of lots
        int M = 0;
        for (int i = 0; i < num_records; i++) {
            if (records[i].lot_index + 1 > M)
                M = records[i].lot_index + 1;
        }

        // Allocate arrays for storing durations per lot
        int **lot_durations = malloc(M * sizeof(int*));
        if (!lot_durations) {
            perror("Memory allocation failed");
            free(records);
            return 1;
        }

        int *lot_counts = calloc(M, sizeof(int));
        if (!lot_counts) {
            perror("Memory allocation failed");
            free(records);
            free(lot_durations);
            return 1;
        }

        // Allocate space for durations in each lot
        for (int i = 0; i < M; i++) {
            lot_durations[i] = malloc(num_records * sizeof(int));
            if (!lot_durations[i]) {
                perror("Memory allocation failed");
                for (int j = 0; j < i; j++) free(lot_durations[j]);
                free(lot_durations);
                free(lot_counts);
                free(records);
                return 1;
            }
        }

        // Calculate and store durations for each lot
        for (int i = 0; i < num_records; i++) {
            int duration = records[i].exit_time - records[i].entry_time;
            if (duration < 0) duration += 24 * 60; // Handle overnight parking
            lot_durations[records[i].lot_index][lot_counts[records[i].lot_index]++] = duration;
        }

        // Calculate and print median for each lot
        for (int i = 0; i < M; i++) {
            if (lot_counts[i] == 0) {
                printf("%d 0.000000\n", i);
                continue;
            }

            merge_sort_int(lot_durations[i], 0, lot_counts[i] - 1);
            double median = calculate_median(lot_durations[i], lot_counts[i]);
            printf("%d %.6lf\n", i, median);
        }

        // Free allocated memory
        for (int i = 0; i < M; i++) free(lot_durations[i]);
        free(lot_durations);
        free(lot_counts);
    }
    else if (mode == 'o') {
        /* Mode 'o': Calculate maximum parking occupancy
         * Algorithm:
         * 1. Sort records by entry and exit times separately
         * 2. Use merge-like process to track occupancy changes
         * 3. Keep track of maximum occupancy observed
         */

        // Create and sort arrays for entry and exit times
        ParkingRecord *entry_sorted = malloc(num_records * sizeof(ParkingRecord));
        ParkingRecord *exit_sorted = malloc(num_records * sizeof(ParkingRecord));
        if (!entry_sorted || !exit_sorted) {
            perror("Memory allocation failed");
            free(records);
            if (entry_sorted) free(entry_sorted);
            if (exit_sorted) free(exit_sorted);
            return 1;
        }

        memcpy(entry_sorted, records, num_records * sizeof(ParkingRecord));
        memcpy(exit_sorted, records, num_records * sizeof(ParkingRecord));

        merge_sort_records(entry_sorted, 0, num_records - 1, 0);  // Sort by entry time
        merge_sort_records(exit_sorted, 0, num_records - 1, 1);   // Sort by exit time

        // Calculate maximum occupancy
        int i_entry = 0, i_exit = 0;
        int current_occupancy = 0;
        int max_occupancy = 0;

        while (i_entry < num_records && i_exit < num_records) {
            if (entry_sorted[i_entry].entry_time <= exit_sorted[i_exit].exit_time) {
                current_occupancy++;
                if (current_occupancy > max_occupancy)
                    max_occupancy = current_occupancy;
                i_entry++;
            }
            else {
                current_occupancy--;
                i_exit++;
            }
        }

        printf("%d\n", max_occupancy);

        free(entry_sorted);
        free(exit_sorted);
    }
    else {
        fprintf(stderr, "Invalid mode. Use 'p', 'd', or 'o'.\n");
        free(records);
        return 1;
    }

    free(records);
    return 0;
}

/* Merge sort implementation for ParkingRecord arrays
 * key determines which field to sort by:
 * 0: entry_time
 * 1: exit_time
 * 2: lot_index
 * 3: permit_num
 * 4: original_order
 */
void merge_sort_records(ParkingRecord arr[], int left, int right, int key) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort_records(arr, left, mid, key);
        merge_sort_records(arr, mid + 1, right, key);
        merge_records(arr, left, mid, right, key);
    }
}

// Merge function for ParkingRecord arrays
void merge_records(ParkingRecord arr[], int left, int mid, int right, int key) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    ParkingRecord *L = malloc(n1 * sizeof(ParkingRecord));
    ParkingRecord *R = malloc(n2 * sizeof(ParkingRecord));
    if (!L || !R) {
        perror("Memory allocation failed");
        exit(1);
    }

    for (int i = 0; i < n1; i++)
        L[i] = arr[left + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        // Compare records based on specified key
        int cmp;
        switch (key) {
            case 0: cmp = L[i].entry_time - R[j].entry_time; break;
            case 1: cmp = L[i].exit_time - R[j].exit_time; break;
            case 2: cmp = L[i].lot_index - R[j].lot_index; break;
            case 3: cmp = L[i].permit_num - R[j].permit_num; break;
            case 4: cmp = L[i].original_order - R[j].original_order; break;
            default: cmp = 0;
        }

        if (cmp <= 0) {
            arr[k++] = L[i++];
        }
        else {
            arr[k++] = R[j++];
        }
    }

    while (i < n1)
        arr[k++] = L[i++];
    while (j < n2)
        arr[k++] = R[j++];

    free(L);
    free(R);
}

// Standard merge sort implementation for integer arrays
void merge_sort_int(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort_int(arr, left, mid);
        merge_sort_int(arr, mid + 1, right);
        merge_int(arr, left, mid, right);
    }
}

// Merge function for integer arrays
void merge_int(int arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int *L = malloc(n1 * sizeof(int));
    int *R = malloc(n2 * sizeof(int));
    if (!L || !R) {
        perror("Memory allocation failed");
        exit(1);
    }

    for (int i = 0; i < n1; i++)
        L[i] = arr[left + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k++] = L[i++];
        }
        else {
            arr[k++] = R[j++];
        }
    }

    while (i < n1)
        arr[k++] = L[i++];
    while (j < n2)
        arr[k++] = R[j++];

    free(L);
    free(R);
}

// Convert time string in "HH:MM" format to minutes since midnight
int time_to_minutes(char *time_str) {
    int hours, minutes;
    if (sscanf(time_str, "%d:%d", &hours, &minutes) != 2) {
        fprintf(stderr, "Invalid time format: %s\n", time_str);
        return 0;
    }
    return hours * 60 + minutes;
}

// Calculate median value from a sorted array of integers
double calculate_median(int durations[], int count) {
    if (count % 2 == 1) {
        return (double)durations[count / 2];
    }
    else {
        return (durations[(count / 2) - 1] + durations[count / 2]) / 2.0;
    }
}
