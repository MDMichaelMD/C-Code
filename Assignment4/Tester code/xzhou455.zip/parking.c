#include <stdio.h>
#include <stdlib.h>

// Define parking record structure
typedef struct {
    int entry_hour, entry_minute;
    int exit_hour, exit_minute;
    int lot_index;
    int permit_number;
} ParkingRecord;

// Event structure to represent entry or exit events
typedef struct {
    int time_in_minutes;
    int type; // 1 indicates entry, -1 indicates exit
} ParkingEvent;

// Merge function for merge sort of ParkingRecord array (sorted by permit_number)
void merge_parking_records(ParkingRecord arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    
    ParkingRecord *L = (ParkingRecord *)malloc(n1 * sizeof(ParkingRecord));
    ParkingRecord *R = (ParkingRecord *)malloc(n2 * sizeof(ParkingRecord));

    for (int i = 0; i < n1; i++) L[i] = arr[left + i];
    for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i].permit_number <= R[j].permit_number) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    free(L);
    free(R);
}

void merge_sort_parking_records(ParkingRecord arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort_parking_records(arr, left, mid);
        merge_sort_parking_records(arr, mid + 1, right);
        merge_parking_records(arr, left, mid, right);
    }
}

// Merge function for merge sort of ParkingEvent array (sorted by time)
void merge_events(ParkingEvent arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    ParkingEvent *L = (ParkingEvent *)malloc(n1 * sizeof(ParkingEvent));
    ParkingEvent *R = (ParkingEvent *)malloc(n2 * sizeof(ParkingEvent));

    for (int i = 0; i < n1; i++) L[i] = arr[left + i];
    for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i].time_in_minutes < R[j].time_in_minutes || 
            (L[i].time_in_minutes == R[j].time_in_minutes && L[i].type > R[j].type)) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    free(L);
    free(R);
}

void merge_sort_events(ParkingEvent arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort_events(arr, left, mid);
        merge_sort_events(arr, mid + 1, right);
        merge_events(arr, left, mid, right);
    }
}

// Merge function for merge sort of integer array
void merge_ints(int arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int *L = (int *)malloc(n1 * sizeof(int));
    int *R = (int *)malloc(n2 * sizeof(int));

    for (int i = 0; i < n1; i++) L[i] = arr[left + i];
    for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    free(L);
    free(R);
}

void merge_sort_ints(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort_ints(arr, left, mid);
        merge_sort_ints(arr, mid + 1, right);
        merge_ints(arr, left, mid, right);
    }
}

// Process p parameter, output parking records with the same permit_number
void process_p_parameter(ParkingRecord records[], int num_records) {
    ParkingRecord *sorted_records = malloc(num_records * sizeof(ParkingRecord));
    for (int i = 0; i < num_records; i++) {
        sorted_records[i] = records[i];
    }

    merge_sort_parking_records(sorted_records, 0, num_records - 1);

    for (int i = 0; i < num_records; i++) {
        int permit_number = sorted_records[i].permit_number;
        int count = 0;

        // Count records with the same permit_number
        while (i + count < num_records && sorted_records[i + count].permit_number == permit_number) {
            count++;
        }

        // If multiple records with the same permit_number are found, output them
        if (count > 1) {
            for (int j = 0; j < count; j++) {
                printf("%d %d %02d:%02d %02d:%02d\n",
                       sorted_records[i + j].permit_number,
                       sorted_records[i + j].lot_index,
                       sorted_records[i + j].entry_hour, sorted_records[i + j].entry_minute,
                       sorted_records[i + j].exit_hour, sorted_records[i + j].exit_minute);
            }
        }

        // Skip processed records
        i += count - 1;  // -1 because outer loop increments i
    }

    free(sorted_records);
}

// Calculate the maximum occupancy of the parking lot
void calculate_maximum_occupancy(ParkingRecord records[], int num_records) {
    ParkingEvent *events = (ParkingEvent *)malloc(2 * num_records * sizeof(ParkingEvent));
    int event_count = 0;

    for (int i = 0; i < num_records; i++) {
        events[event_count++] = (ParkingEvent) {
            .time_in_minutes = records[i].entry_hour * 60 + records[i].entry_minute,
            .type = 1
        };
        events[event_count++] = (ParkingEvent) {
            .time_in_minutes = records[i].exit_hour * 60 + records[i].exit_minute,
            .type = -1
        };
    }

    merge_sort_events(events, 0, event_count - 1);

    int current_occupancy = 0;
    int max_occupancy = 0;
    for (int i = 0; i < event_count; i++) {
        current_occupancy += events[i].type;
        if (current_occupancy > max_occupancy) {
            max_occupancy = current_occupancy;
        }
    }

    printf("%d\n", max_occupancy);
    free(events);
}

// Calculate the median parking duration for each parking lot
void calculate_median_duration_by_lot(ParkingRecord records[], int num_records) {
    int max_lot_index = 0;

    for (int i = 0; i < num_records; i++) {
        if (records[i].lot_index > max_lot_index) {
            max_lot_index = records[i].lot_index;
        }
    }

    for (int lot = 0; lot <= max_lot_index; lot++) {
        int count = 0;
        int *durations = (int *)malloc(num_records * sizeof(int));

        for (int i = 0; i < num_records; i++) {
            if (records[i].lot_index == lot) {
                durations[count++] = (records[i].exit_hour * 60 + records[i].exit_minute) -
                                     (records[i].entry_hour * 60 + records[i].entry_minute);
            }
        }

        if (count == 0) {
            free(durations);
            continue;
        }

        merge_sort_ints(durations, 0, count - 1);

        double median;
        if (count % 2 == 0) {
            median = (durations[count / 2 - 1] + durations[count / 2]) / 2.0;
        } else {
            median = durations[count / 2];
        }

        printf("%d %.6f\n", lot, median);
        free(durations);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <input_file> <operation>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error opening file.\n");
        return 1;
    }

    int num_records;
    fscanf(file, "%d", &num_records);

    ParkingRecord *records = (ParkingRecord *)malloc(num_records * sizeof(ParkingRecord));
    for (int i = 0; i < num_records; i++) {
        fscanf(file, "%d:%d %d:%d %d %d",
               &records[i].entry_hour, &records[i].entry_minute,
               &records[i].exit_hour, &records[i].exit_minute,
               &records[i].lot_index, &records[i].permit_number);
    }
    fclose(file);

    char operation = argv[2][0];
    switch (operation) {
        case 'p':
            process_p_parameter(records, num_records);
            break;
        case 'd':
            calculate_median_duration_by_lot(records, num_records);
            break;
        case 'o':
            calculate_maximum_occupancy(records, num_records);
            break;
        default:
            printf("Unknown operation.\n");
            break;
    }

    free(records);
    return 0;
}
