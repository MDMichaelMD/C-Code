#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Assuming the definition of ParkingRecord
typedef struct {
    int entryHour;
    int entryMinute;
    int exitHour;
    int exitMinute;
    int lotIndex;
    int permitNumber;
    int duration;
} ParkingRecord;

// Function prototypes
ParkingRecord* readData(const char* filename, int* count);
void mergeSort(ParkingRecord data[], int left, int right, int key);
void merge(ParkingRecord data[], int left, int mid, int right, int key);
int compare(ParkingRecord a, ParkingRecord b, int key);
void findDuplicatePermits(ParkingRecord records[], int count);
void calculateMedianDurations(ParkingRecord records[], int count);
void calculateMaximumOccupancy(ParkingRecord records[], int count);

int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: ./parking <input_file> <p/d/o>\n");
        return 1;
    }
    const char* filename = argv[1];
    char mode = argv[2][0];

    ParkingRecord* records = NULL;
    int count = 0;
    records = readData(filename, &count);

    if (!records) {
        return 1;
    }

    switch (mode) {
        case 'p':
            findDuplicatePermits(records, count);
            break;
        case 'd':
            calculateMedianDurations(records, count);
            break;
        case 'o':
            calculateMaximumOccupancy(records, count);
            break;
        default:
            fprintf(stderr, "Invalid mode\n");
            break;
    }

    free(records);
    return 0;
}

// Function to read data from file and populate the ParkingRecord array
ParkingRecord* readData(const char* filename, int* count) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("File open error");
        exit(1);
    }

    fscanf(file, "%d", count);
    ParkingRecord* records = (ParkingRecord*)malloc((*count) * sizeof(ParkingRecord));
    for (int i = 0; i < *count; i++) {
        fscanf(file, "%d:%d %d:%d %d %d",
               &records[i].entryHour, &records[i].entryMinute,
               &records[i].exitHour, &records[i].exitMinute,
               &records[i].lotIndex, &records[i].permitNumber);
    }
    fclose(file);
    return records;
}

// Merge Sort
void mergeSort(ParkingRecord data[], int left, int right, int key) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(data, left, mid, key);
        mergeSort(data, mid + 1, right, key);
        merge(data, left, mid, right, key);
    }
}

// Merge function
void merge(ParkingRecord data[], int left, int mid, int right, int key) {
    int l1 = mid - left + 1;
    int l2 = right - mid;
    ParkingRecord* L = (ParkingRecord*)malloc(l1 * sizeof(ParkingRecord));
    ParkingRecord* R = (ParkingRecord*)malloc(l2 * sizeof(ParkingRecord));

    for (int i = 0; i < l1; i++) L[i] = data[left + i];
    for (int j = 0; j < l2; j++) R[j] = data[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < l1 && j < l2) {
        if (compare(L[i], R[j], key) <= 0) data[k++] = L[i++];
        else data[k++] = R[j++];
    }

    while (i < l1) data[k++] = L[i++];
    while (j < l2) data[k++] = R[j++];

    free(L);
    free(R);
}

// Comparison function
int compare(ParkingRecord a, ParkingRecord b, int key) {
    if (key == 0) return a.permitNumber - b.permitNumber;
    else if (key == 1) return a.lotIndex - b.lotIndex;
    else if (key == 2) {
        int durA = (a.exitHour * 60 + a.exitMinute) - (a.entryHour * 60 + a.entryMinute);
        int durB = (b.exitHour * 60 + b.exitMinute) - (b.entryHour * 60 + b.entryMinute);
        return durA - durB;
    }
    else if (key == 3) {
        int entryA = a.entryHour * 60 + a.entryMinute;
        int entryB = b.entryHour * 60 + b.entryMinute;
        return entryA - entryB;
    }
    else if (key == 4) {
        int exitA = a.exitHour * 60 + a.exitMinute;
        int exitB = b.exitHour * 60 + b.exitMinute;
        return exitA - exitB;
    }
    else {
        return 0;
    }
}

// Find duplicate permits
void findDuplicatePermits(ParkingRecord records[], int count) {
    mergeSort(records, 0, count - 1, 0);

    int* duplicates = (int*)malloc(count * sizeof(int));
    int duplicateCount = 0;

    for (int i = 1; i < count; i++) {
        if (records[i].permitNumber == records[i - 1].permitNumber) {
            if (duplicateCount == 0 || records[i].permitNumber != duplicates[duplicateCount - 1]) {
                duplicates[duplicateCount++] = records[i].permitNumber;
            }
        }
    }

    for (int i = 0; i < count; i++) {
        int isDuplicate = 0;
        for (int j = 0; j < duplicateCount; j++) {
            if (records[i].permitNumber == duplicates[j]) {
                isDuplicate = 1;
                break;
            }
        }
        if (isDuplicate) {
            printf("%d %d %02d:%02d %02d:%02d\n", records[i].permitNumber, records[i].lotIndex,
                   records[i].entryHour, records[i].entryMinute,
                   records[i].exitHour, records[i].exitMinute);
        }
    }

    free(duplicates);
}

// Calculate median durations
void calculateMedianDurations(ParkingRecord records[], int count) {
    for (int i = 0; i < count; i++) {
        records[i].duration = (records[i].exitHour * 60 + records[i].exitMinute) - (records[i].entryHour * 60 + records[i].entryMinute);
    }

    mergeSort(records, 0, count - 1, 1);

    int i = 0;
    while (i < count) {
        int lotIndex = records[i].lotIndex;
        int j = i;
        while (j < count && records[j].lotIndex == lotIndex) j++;

        int lotCount = j - i;
        ParkingRecord* temp = (ParkingRecord*)malloc(lotCount * sizeof(ParkingRecord));
        memcpy(temp, &records[i], lotCount * sizeof(ParkingRecord));
        mergeSort(temp, 0, lotCount - 1, 2);

        double median;
        if (lotCount % 2 == 1) {
            median = temp[lotCount / 2].duration;
        }
        else {
            median = (temp[lotCount / 2 - 1].duration + temp[lotCount / 2].duration) / 2.0;
        }
        printf("%d %.6f\n", lotIndex, median);
        free(temp);
        i = j;
    }
}

// Calculate maximum occupancy
void calculateMaximumOccupancy(ParkingRecord records[], int count) {
    ParkingRecord* entries = (ParkingRecord*)malloc(count * sizeof(ParkingRecord));
    ParkingRecord* exits = (ParkingRecord*)malloc(count * sizeof(ParkingRecord));
    memcpy(entries, records, count * sizeof(ParkingRecord));
    memcpy(exits, records, count * sizeof(ParkingRecord));

    mergeSort(entries, 0, count - 1, 3);
    mergeSort(exits, 0, count - 1, 4);

    int currentOccupancy = 0, maxOccupancy = 0;
    int i = 0, j = 0;

    while (i < count && j < count) {
        int entryTime = entries[i].entryHour * 60 + entries[i].entryMinute;
        int exitTime = exits[j].exitHour * 60 + exits[j].exitMinute;

        if (entryTime <= exitTime) {
            currentOccupancy++;
            if (currentOccupancy > maxOccupancy) maxOccupancy = currentOccupancy;
            i++;
        }
        else {
            currentOccupancy--;
            j++;
        }
    }
    printf("%d\n", maxOccupancy);
    free(entries);
    free(exits);
}
